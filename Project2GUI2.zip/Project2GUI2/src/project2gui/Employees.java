package project2gui;

import java.util.ArrayList;

/**
 *
 * @author Matt
 */
public class Employees {
    private static ArrayList employees = new ArrayList();
    
    public void add(Employee employee) {
        employees.add(employee);
    }
    
    public Employee get(int i){
        return (Employee) employees.get(i);
    }
    
    public int size() {
        return employees.size();
    }
    
    public void clear() {
        employees.clear();
    }
}
