package project2gui;

import java.io.File;
import javafx.beans.binding.BooleanBinding;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.DirectoryChooser;
import javafx.stage.Stage;

/**
 * GUI for Database Operations.
 *
 * @author Matt
 */
public class DatabaseOperationsGUI {

    private static Stage stage = new Stage();
    private static BorderPane borderPane = new BorderPane();
    private static Scene scene = new Scene(borderPane, 500, 450);
    private static String dbPath = "";

    static BorderPane selectDatabasePane() {
        Label selectLabel = new Label("Point to database directory:");

        HBox buttonBox = new HBox(30);
        buttonBox.setAlignment(Pos.CENTER);

        Button openButton = new Button();
        openButton.setMinWidth(200);
        openButton.setText("Select Directory");
        openButton.setOnAction((ActionEvent event) -> {
            databaseChooser();
        });
        buttonBox.getChildren().add(openButton);

        borderPane.setCenter(selectLabel);
        borderPane.setBottom(buttonBox);
        BorderPane.setMargin(buttonBox, new Insets(30, 30, 100, 30));
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();

        return borderPane;
    }

    static void databaseChooser() {
        DirectoryChooser directoryChooser = new DirectoryChooser();
        directoryChooser.setTitle("Select Database Directory");
        File directory = directoryChooser.showDialog(stage);
        dbPath = directory.toString();
        DatabaseOperationsHelper dbh = new DatabaseOperationsHelper();
        dbh.setPath(dbPath);
        System.out.println("Directory path set as: " + dbPath);

        borderPane = checkDirectToDatabase();
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();
    }

    static BorderPane checkDirectToDatabase() {
        Label selectLabel1 = new Label("Database path set as:");
        Label selectLabel2 = new Label(dbPath);
        selectLabel2.setFont(javafx.scene.text.Font.font("Courier New", 12));
        Label selectLabel3 = new Label("Accept this path?");

        VBox labelBox = new VBox(30);
        labelBox.setAlignment(Pos.CENTER);

        HBox buttonBox = new HBox(30);
        buttonBox.setAlignment(Pos.CENTER);

        Button okayButton = new Button();
        okayButton.setMinWidth(100);
        okayButton.setText("Accept");
        okayButton.setOnAction((ActionEvent event) -> {
            borderPane = databaseOperationsPane();
        });

        Button reselectButton = new Button();
        reselectButton.setMinWidth(100);
        reselectButton.setText("Reject");
        reselectButton.setOnAction((ActionEvent event) -> {
            databaseChooser();
        });

        labelBox.getChildren().addAll(selectLabel1, selectLabel2, selectLabel3);
        buttonBox.getChildren().addAll(okayButton, reselectButton);
        borderPane.setCenter(labelBox);
        borderPane.setBottom(buttonBox);
        BorderPane.setMargin(buttonBox, new Insets(30, 30, 100, 30));

        stage.setTitle("Confirm Database");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();

        return borderPane;
    }

    static BorderPane databaseOperationsPane() {

        VBox buttonBox = new VBox(20);
        VBox buttonBox2 = new VBox(20);

        Button insertButton = new Button();
        insertButton.setMinWidth(200);
        insertButton.setText("Insert");
        insertButton.setOnAction((ActionEvent event) -> {
            borderPane = insertStage();
        });

        Button retrieveButton = new Button();
        retrieveButton.setMinWidth(200);
        retrieveButton.setText("Retrieve");
        retrieveButton.setOnAction((ActionEvent event) -> {
            retrievePane();
        });

        Button modifyButton = new Button();
        modifyButton.setMinWidth(200);
        modifyButton.setText("Modify");
        modifyButton.setOnAction((ActionEvent event) -> {
            borderPane = modifyPane();
        });

        Button deleteButton = new Button();
        deleteButton.setMinWidth(200);
        deleteButton.setText("Delete");
        deleteButton.setOnAction((ActionEvent event) -> {
            borderPane = deletePane();
        });

        Button selectNewDBButton = new Button();
        selectNewDBButton.setMinWidth(200);
        selectNewDBButton.setText("Select Database");
        selectNewDBButton.setOnAction((ActionEvent event) -> {
            databaseChooser();
        });

        Button closeButton = new Button();
        closeButton.setMinWidth(200);
        closeButton.setText("Close");
        closeButton.setOnAction((ActionEvent event) -> {
            stage.close();
        });

        buttonBox.getChildren().addAll(insertButton, retrieveButton,
                modifyButton, deleteButton);
        buttonBox.setAlignment(Pos.CENTER);

        buttonBox2.getChildren().addAll(selectNewDBButton, closeButton);
        buttonBox2.setAlignment(Pos.CENTER);

        borderPane.setCenter(buttonBox);
        borderPane.setBottom(buttonBox2);
        BorderPane.setMargin(buttonBox2, new Insets(30, 30, 30, 30));

        stage.setTitle("Derby Database GUI");
        stage.setResizable(false);
        stage.setScene(scene);
        stage.show();

        return borderPane;
    }

    static BorderPane insertStage() {

        Label nameLabel = new Label("Employee Name:");
        Label employeeNumberLabel = new Label("Employee Number:");
        Label territoryNumberLabel = new Label("Territory Number:");
        Label annualSalaryLabel = new Label("Annual Salary:");

        TextField nameTextField = new TextField();
        TextField employeeNumberTextField = new TextField();
        TextField territoryNumberTextField = new TextField();
        TextField annualSalaryTextField = new TextField();

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(5);
        gridPane.setHgap(5);

        GridPane.setConstraints(nameLabel, 0, 0);
        GridPane.setConstraints(nameTextField, 1, 0);
        GridPane.setConstraints(employeeNumberLabel, 0, 1);
        GridPane.setConstraints(employeeNumberTextField, 1, 1);
        GridPane.setConstraints(territoryNumberLabel, 0, 2);
        GridPane.setConstraints(territoryNumberTextField, 1, 2);
        GridPane.setConstraints(annualSalaryLabel, 0, 3);
        GridPane.setConstraints(annualSalaryTextField, 1, 3);
        gridPane.getChildren().addAll(nameLabel, nameTextField,
                employeeNumberLabel, employeeNumberTextField,
                territoryNumberLabel, territoryNumberTextField,
                annualSalaryLabel, annualSalaryTextField);
        gridPane.setAlignment(Pos.CENTER);
        borderPane.setCenter(gridPane);

        HBox buttonBox = new HBox(30);

        buttonBox.setAlignment(Pos.CENTER);

        Button checkButton = new Button("Check Entry");
        checkButton.setMinWidth(80);
        buttonBox.getChildren().add(checkButton);

        Label errorText = new Label("");

        Button cancelButton = new Button("Cancel");
        cancelButton.setMinWidth(80);
        buttonBox.getChildren().add(cancelButton);
        cancelButton.setOnAction((ActionEvent event) -> {
            borderPane = databaseOperationsPane();
        });

        BooleanBinding disableCheck = new BooleanBinding() {
            {
                super.bind(nameTextField.textProperty(),
                        employeeNumberTextField.textProperty(),
                        territoryNumberTextField.textProperty(),
                        annualSalaryTextField.textProperty());
            }

            @Override
            protected boolean computeValue() {
                return (nameTextField.getText().isEmpty()
                        || employeeNumberTextField.getText().isEmpty()
                        || territoryNumberTextField.getText().isEmpty()
                        || annualSalaryTextField.getText().isEmpty());
            }
        };

        checkButton.disableProperty().bind(disableCheck);
        checkButton.setOnAction((ActionEvent event) -> {
            if (!DatabaseOperationsHelper.usedEmployeeNumbers().contains(employeeNumberTextField.getText())) {
                errorText.setText("");
                buttonBox.getChildren().remove(checkButton);
                buttonBox.getChildren().remove(cancelButton);

                Button submitButton = new Button("Submit");
                submitButton.setMinWidth(80);
                buttonBox.getChildren().addAll(submitButton, cancelButton);
                submitButton.setOnAction((ActionEvent event2) -> {
                    Employee employee = new Employee();
                    employee.setEmployeeName(nameTextField.getText().toUpperCase());
                    employee.setEmployeeNumber(Integer.parseInt(employeeNumberTextField.getText()));
                    employee.setTerritoryNumber(Integer.parseInt(territoryNumberTextField.getText()));
                    employee.setAnnualSalary(Integer.parseInt(annualSalaryTextField.getText()));
                    DatabaseOperationsHelper.insert(employee);

                    Label successText = new Label("Employee successfully inserted into table!");

                    HBox hb = new HBox(20);
                    hb.setAlignment(Pos.CENTER);

                    Button okayButton = new Button("Okay");
                    hb.getChildren().add(okayButton);
                    okayButton.setOnAction((ActionEvent event3) -> {
                        borderPane = databaseOperationsPane();
                    });

                    borderPane.setCenter(successText);
                    borderPane.setBottom(hb);
                    BorderPane.setMargin(hb, new Insets(10, 10, 80, 10));
                    borderPane = databaseOperationsPane();
                });
            } else {
                errorText.setText("Employee Number already listed on table");
            }
        });

        VBox labelAndButtons = new VBox(10);
        labelAndButtons.getChildren().addAll(errorText, buttonBox);
        labelAndButtons.setAlignment(Pos.CENTER);

        borderPane.setBottom(labelAndButtons);
        BorderPane.setMargin(labelAndButtons, new Insets(10, 10, 80, 10));

        stage.setTitle("Insert");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        return borderPane;
    }

    static void retrievePane() {
        Stage retrieveStage = new Stage();
        BorderPane retrievePane = new BorderPane();

        Label output = new Label(DatabaseOperationsHelper.retrieveOutputString());
        output.setFont(javafx.scene.text.Font.font("Courier New", 12));
        ScrollPane scrollPane = new ScrollPane(output);
        scrollPane.setPadding(new Insets(50, 10, 10, 90));
        scrollPane.setFitToWidth(true);

        retrievePane.setCenter(scrollPane);

        HBox buttonBox = new HBox(20);
        buttonBox.setAlignment(Pos.CENTER);

        Button closeButton = new Button("Close");
        closeButton.setMinWidth(80);
        buttonBox.getChildren().add(closeButton);
        closeButton.setOnAction((ActionEvent event) -> {
            borderPane = databaseOperationsPane();
            retrieveStage.close();
        });

        retrievePane.setBottom(buttonBox);
        BorderPane.setMargin(buttonBox, new Insets(10, 10, 10, 10));
        Scene retrieveScene = new Scene(retrievePane, 800, 450);

        retrieveStage.setTitle("Derby Database Records");
        retrieveStage.setScene(retrieveScene);
        retrieveStage.setResizable(false);
        retrieveStage.show();
    }

    static BorderPane modifyPane() {

        CheckBox employeeNameCheck = new CheckBox();
        CheckBox territoryNumberCheck = new CheckBox();
        CheckBox annualSalaryCheck = new CheckBox();

        Label employeeNumberLabel = new Label("Employee Number:");
        Label empty = new Label("");
        Label employeeNameLabel = new Label("Employee Name:");
        Label territoryNumberLabel = new Label("Territory Number:");
        Label annualSalaryLabel = new Label("Annual Salary:");

        TextField employeeNumberTextField = new TextField();
        employeeNumberTextField.setPrefColumnCount(3);
        TextField employeeNameTextField = new TextField();
        TextField territoryNumberTextField = new TextField();
        TextField annualSalaryTextField = new TextField();

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(5);
        gridPane.setHgap(5);

        GridPane.setConstraints(employeeNumberLabel, 1, 0);
        GridPane.setConstraints(employeeNumberTextField, 2, 0);
        GridPane.setConstraints(empty, 0, 1);
        GridPane.setConstraints(empty, 1, 1);
        GridPane.setConstraints(employeeNameCheck, 0, 2);
        GridPane.setConstraints(employeeNameLabel, 1, 2);
        GridPane.setConstraints(employeeNameTextField, 2, 2);
        GridPane.setConstraints(territoryNumberCheck, 0, 3);
        GridPane.setConstraints(territoryNumberLabel, 1, 3);
        GridPane.setConstraints(territoryNumberTextField, 2, 3);
        GridPane.setConstraints(annualSalaryCheck, 0, 4);
        GridPane.setConstraints(annualSalaryLabel, 1, 4);
        GridPane.setConstraints(annualSalaryTextField, 2, 4);
        gridPane.getChildren().addAll(employeeNumberLabel, employeeNumberTextField,
                empty,
                employeeNameCheck, employeeNameLabel,
                employeeNameTextField, territoryNumberCheck,
                territoryNumberLabel, territoryNumberTextField, annualSalaryCheck,
                annualSalaryLabel, annualSalaryTextField);
        gridPane.setAlignment(Pos.CENTER);
        borderPane.setCenter(gridPane);

        HBox buttonBox = new HBox(30);

        buttonBox.setAlignment(Pos.CENTER);

        Button submitButton = new Button("Submit");
        submitButton.setMinWidth(80);
        buttonBox.getChildren().add(submitButton);

        BooleanBinding disableCheckBox = new BooleanBinding() {
            {
                super.bind(employeeNumberTextField.textProperty());
            }

            @Override
            protected boolean computeValue() {
                return (!DatabaseOperationsHelper.usedEmployeeNumbers().contains(employeeNumberTextField.getText()));
            }
        };

        BooleanBinding disableSubmit = new BooleanBinding() {
            {
                super.bind(employeeNameTextField.textProperty(),
                        territoryNumberTextField.textProperty(),
                        annualSalaryTextField.textProperty());
            }

            @Override
            protected boolean computeValue() {
                return (employeeNameTextField.getText().isEmpty()
                        && territoryNumberTextField.getText().isEmpty()
                        && annualSalaryTextField.getText().isEmpty());
            }
        };

        BooleanBinding disableEmployeeNameTextField = new BooleanBinding() {
            {
                super.bind(employeeNameCheck.selectedProperty());
            }

            @Override
            protected boolean computeValue() {
                return (!employeeNameCheck.isSelected());
            }
        };

        BooleanBinding disableTerritoryNumberTextField = new BooleanBinding() {
            {
                super.bind(territoryNumberCheck.selectedProperty());
            }

            @Override
            protected boolean computeValue() {
                return (!territoryNumberCheck.isSelected());
            }
        };

        BooleanBinding disableAnnualSalaryTextField = new BooleanBinding() {
            {
                super.bind(annualSalaryCheck.selectedProperty());
            }

            @Override
            protected boolean computeValue() {
                return (!annualSalaryCheck.isSelected());
            }
        };

        employeeNameCheck.disableProperty().bind(disableCheckBox);
        territoryNumberCheck.disableProperty().bind(disableCheckBox);
        annualSalaryCheck.disableProperty().bind(disableCheckBox);
        employeeNameTextField.disableProperty().bind(disableEmployeeNameTextField);
        territoryNumberTextField.disableProperty().bind(disableTerritoryNumberTextField);
        annualSalaryTextField.disableProperty().bind(disableAnnualSalaryTextField);
        submitButton.disableProperty().bind(disableSubmit);

        submitButton.setOnAction((ActionEvent event) -> {
            Employee employee = new Employee();
            employee.setEmployeeNumber(Integer.parseInt(employeeNumberTextField.getText()));
            if (!employeeNameTextField.getText().isEmpty()) {
                employee.setEmployeeName(employeeNameTextField.getText().toUpperCase());
                DatabaseOperationsHelper.modifyName(employee.getEmployeeName(), employee.getEmployeeNumber());
            }
            if (!territoryNumberTextField.getText().isEmpty()) {
                employee.setTerritoryNumber(Integer.parseInt(territoryNumberTextField.getText()));
                DatabaseOperationsHelper.modifyTerritoryNumber(employee.getTerritoryNumber(), employee.getEmployeeNumber());
            }
            if (!annualSalaryTextField.getText().isEmpty()) {
                employee.setAnnualSalary(Integer.parseInt(annualSalaryTextField.getText()));
                DatabaseOperationsHelper.modifyAnnualSalary(employee.getAnnualSalary(), employee.getEmployeeNumber());
            }

            Label successText = new Label("Employee successfully modified!");

            HBox hb = new HBox(30);
            hb.setAlignment(Pos.CENTER);

            Button okayButton = new Button("Okay");
            okayButton.setMinWidth(80);
            hb.getChildren().add(okayButton);
            okayButton.setOnAction((ActionEvent event2) -> {
                borderPane = databaseOperationsPane();
            });

            borderPane.setCenter(successText);
            borderPane.setBottom(hb);
            BorderPane.setMargin(hb, new Insets(10, 10, 80, 10));
        });

        Button cancelButton = new Button("Cancel");
        cancelButton.setMinWidth(80);
        buttonBox.getChildren().add(cancelButton);
        cancelButton.setOnAction((ActionEvent event) -> {
            borderPane = databaseOperationsPane();
        });

        borderPane.setBottom(buttonBox);
        BorderPane.setMargin(buttonBox, new Insets(10, 10, 80, 10));

        stage.setTitle("Modify");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        return borderPane;
    }

    static BorderPane deletePane() {

        GridPane gridPane = new GridPane();
        gridPane.setPadding(new Insets(10, 10, 10, 10));
        gridPane.setVgap(5);
        gridPane.setHgap(5);

        Label employeeNumberLabel = new Label("Employee Number:");
        TextField employeeNumberTextField = new TextField();
        employeeNumberTextField.setPrefColumnCount(3);

        GridPane.setConstraints(employeeNumberLabel, 0, 1);
        GridPane.setConstraints(employeeNumberTextField, 1, 1);

        gridPane.getChildren().addAll(employeeNumberLabel, employeeNumberTextField);
        gridPane.setAlignment(Pos.CENTER);
        borderPane.setCenter(gridPane);

        HBox buttonBox = new HBox(30);

        buttonBox.setAlignment(Pos.CENTER);

        BooleanBinding disableEmployeeNumberTextField = new BooleanBinding() {
            {
                super.bind(employeeNumberTextField.textProperty());
            }

            @Override
            protected boolean computeValue() {
                return (!DatabaseOperationsHelper.usedEmployeeNumbers().contains(employeeNumberTextField.getText()));
            }
        };

        Button submitButton = new Button("Submit");
        submitButton.setMinWidth(80);
        submitButton.disableProperty().bind(disableEmployeeNumberTextField);
        buttonBox.getChildren().add(submitButton);
        submitButton.setOnAction((ActionEvent event) -> {
            DatabaseOperationsHelper.delete(Integer.parseInt(employeeNumberTextField.getText()));

            Label successText = new Label("Employee successfully removed from table!");

            HBox hb = new HBox(20);
            hb.setAlignment(Pos.CENTER);

            Button okayButton = new Button("Okay");
            okayButton.setMinWidth(80);
            hb.getChildren().add(okayButton);
            okayButton.setOnAction((ActionEvent event2) -> {
                borderPane = databaseOperationsPane();
            });

            borderPane.setCenter(successText);
            borderPane.setBottom(hb);
            BorderPane.setMargin(hb, new Insets(10, 10, 80, 10));
        });

        Button cancelButton = new Button("Cancel");
        cancelButton.setMinWidth(80);
        buttonBox.getChildren()
                .add(cancelButton);
        cancelButton.setOnAction(
                (ActionEvent event) -> {
                    borderPane = databaseOperationsPane();
                }
        );

        borderPane.setBottom(buttonBox);

        BorderPane.setMargin(buttonBox, new Insets(10, 10, 80, 10));

        stage.setTitle("Delete");
        stage.setScene(scene);
        stage.setResizable(false);
        stage.show();

        return borderPane;
    }

    public Stage getStage() {
        return stage;
    }

    public void setStage(Stage stage) {
        this.stage = stage;
    }

    public Scene getScene() {
        return scene;
    }

    public void setScene(Scene scene) {
        this.scene = scene;
    }

}
