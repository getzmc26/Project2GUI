package project2gui;

import java.io.File;
import java.io.IOException;
import org.apache.commons.io.FileUtils;
import java.sql.*;
import java.util.ArrayList;

/**
 * Basic Database Operations - Create, Retrieve, Update, Delete
 *
 * @author Matt
 */
public class DatabaseOperationsHelper {

    private static String path;

    private static Connection openConnection() throws SQLException {

        String dbProtocol = "jdbc:derby:";
        String dbDirectory = path;
        System.out.println("DB directory received as: " + path);
        
        String dbName = "PayrollMaster";
        String connectionURL = dbProtocol + dbName;

        System.setProperty("derby.system.home", dbDirectory);
        Connection connection1 = DriverManager.getConnection(connectionURL, "Admin", "MuCis");
        System.out.println(connection1);
        return connection1;
    }

    static void insert(Employee employee) {
        String insertStatementEmployee = "INSERT INTO Payroll"
                + " (EmployeeNumber, Name, TerritoryNumber, AnnualSalary)"
                + "VALUES(?, ?, ?, ?)";
        try (Connection connection1 = openConnection()) {
            PreparedStatement statement = connection1.prepareStatement(insertStatementEmployee);
            statement.setInt(1, employee.getEmployeeNumber());
            statement.setString(2, employee.getEmployeeName());
            statement.setInt(3, employee.getTerritoryNumber());
            statement.setInt(4, employee.getAnnualSalary());
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    static Employee retrieve(int employeeNumber) {
        String query1 = "SELECT * FROM Payroll WHERE EmployeeNumber = ?";
        Employee employee = new Employee();
        try (Connection connection1 = openConnection()) {
            PreparedStatement statement = connection1.prepareStatement(query1);
            statement.setInt(1, employeeNumber);
            ResultSet rs1 = statement.executeQuery();
            while (rs1.next()) {
                employee.setEmployeeNumber(rs1.getInt(1));
                employee.setEmployeeName(rs1.getString(2));
                employee.setTerritoryNumber(rs1.getInt(3));
                employee.setAnnualSalary(rs1.getInt(4));
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return employee;
    }

    static Employees retrieveAll() {
        String query1 = "SELECT * FROM Payroll" + " ORDER BY EmployeeNumber ASC";
        Employees employees = new Employees();
        try (Connection connection1 = openConnection()) {
            Statement statement = connection1.createStatement();
            ResultSet rs1 = statement.executeQuery(query1);
            while (rs1.next()) {
                Employee employeeNext = new Employee();
                employeeNext.setEmployeeNumber(rs1.getInt(1));
                employeeNext.setEmployeeName(rs1.getString(2));
                employeeNext.setTerritoryNumber(rs1.getInt(3));
                employeeNext.setAnnualSalary(rs1.getInt(4));
                employees.add(employeeNext);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return employees;
    }

    static void modifyName(String modifyFieldValue, int conditionFieldValue) {
        String modifyStatement = "UPDATE Payroll SET Name = ?"
                + "WHERE EmployeeNumber = ?";
        try (Connection connection1 = openConnection()) {
            PreparedStatement statement = connection1.prepareStatement(modifyStatement);
            statement.setString(1, modifyFieldValue);
            statement.setInt(2, conditionFieldValue);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    static void modifyTerritoryNumber(int modifyFieldValue, int conditionFieldValue) {
        String modifyStatement = "UPDATE Payroll SET TerritoryNumber = ?"
                + "WHERE EmployeeNumber = ?";
        try (Connection connection1 = openConnection()) {
            PreparedStatement statement = connection1.prepareStatement(modifyStatement);
            statement.setInt(1, modifyFieldValue);
            statement.setInt(2, conditionFieldValue);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    static void modifyAnnualSalary(int modifyFieldValue, int conditionFieldValue) {
        String modifyStatement = "UPDATE Payroll SET AnnualSalary = ?"
                + "WHERE EmployeeNumber = ?";
        try (Connection connection1 = openConnection()) {
            PreparedStatement statement = connection1.prepareStatement(modifyStatement);
            statement.setInt(1, modifyFieldValue);
            statement.setInt(2, conditionFieldValue);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    static void delete(int conditionFieldValue) {
        String deleteStatement = "DELETE FROM Payroll WHERE EmployeeNumber = ?";
        try (Connection connection1 = openConnection()) {
            PreparedStatement statement = connection1.prepareStatement(deleteStatement);
            statement.setInt(1, conditionFieldValue);
            statement.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
    }

    static void retrieveOutput() {
        Employees employees = retrieveAll();
        System.out.println("Employee Number" + addSpaces(9)
                + "Employee Name" + addSpaces(11)
                + "Territory Number" + addSpaces(8)
                + "Annual Salary");
        System.out.println(buildHeading(85));
        for (int i = 0; i < employees.size(); i++) {
            System.out.println((employees.get(i)).getEmployeeNumber()
                    + "\t\t\t"
                    + cleanName((employees.get(i)).getEmployeeName())
                    + "\t"
                    + (employees.get(i)).getTerritoryNumber()
                    + "\t\t\t"
                    + (employees.get(i)).getAnnualSalary());
            System.out.println();
        }
        employees.clear();
    }

    static String retrieveOutputString() {
        String output = "";
        Employees employees = retrieveAll();
        output += ("Employee Number" + addSpaces(9)
                + "Employee Name" + addSpaces(11)
                + "Territory Number" + addSpaces(8)
                + "Annual Salary");
        output += "\n";
        output += (buildHeading(85));
        output += "\n";
        for (int i = 0; i < employees.size(); i++) {
            output += ((employees.get(i)).getEmployeeNumber()
                    + "\t\t\t"
                    + cleanName((employees.get(i)).getEmployeeName())
                    + "\t"
                    + (employees.get(i)).getTerritoryNumber()
                    + "\t\t\t"
                    + (employees.get(i)).getAnnualSalary());
            output += "\n";
        }
        employees.clear();
        return output;
    }

    static void retrieveOutput(int employeeNumber) {
        Employee employee = retrieve(employeeNumber);
        System.out.println("Employee Number" + addSpaces(9)
                + "Employee Name" + addSpaces(11)
                + "Territory Number" + addSpaces(8)
                + "Annual Salary");
        System.out.println(buildHeading(85));
        System.out.println(employee.getEmployeeNumber()
                + "\t\t\t"
                + cleanName(employee.getEmployeeName())
                + "\t"
                + employee.getTerritoryNumber()
                + "\t\t\t"
                + employee.getAnnualSalary());
        System.out.println();
    }

    private static String addSpaces(int numberOfSpaces) {
        StringBuilder sb1 = new StringBuilder(numberOfSpaces);
        for (int i = 0; i < numberOfSpaces; i++) {
            sb1.append(" ");
        }
        return sb1.toString();
    }

    private static String buildHeading(int n) {
        StringBuilder sb1 = new StringBuilder(n);
        for (int i = 0; i < n; i++) {
            sb1.append("-");
        }
        return sb1.toString();
    }

    private static String cleanName(String employeeName) {
        employeeName = addTrailingSpaces(employeeName.trim());
        return employeeName;
    }

    private static String addTrailingSpaces(String employeeName) {
        StringBuilder sb1 = new StringBuilder(20);
        sb1.append(employeeName);
        for (int i = employeeName.length() - 1; i < 20; i++) {
            sb1.append(" ");
        }
        return sb1.toString();
    }

    static void resetDatabase() {
        File dbTemplate = new File("H:/Business Programming Concepts I/Test 2/Project2/databases/PayrollDerbyDatabaseInitialTemplate");
        File dbWrittenToByProject = new File("H:/Business Programming Concepts I/Test 2/Project2/databases/PayrollDerbyDatabase");
        try {
            FileUtils.copyDirectory(dbTemplate, dbWrittenToByProject);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
    }

    static ArrayList<String> usedEmployeeNumbers() {
        ArrayList<String> employeeNums = new ArrayList<>();
        String query1 = "SELECT EmployeeNumber FROM Payroll";
        try (Connection connection1 = openConnection()) {
            Statement statement = connection1.createStatement();
            ResultSet rs1 = statement.executeQuery(query1);
            while (rs1.next()) {
                Employee employeeNext = new Employee();
                employeeNext.setEmployeeNumber(rs1.getInt(1));
                employeeNums.add(String.valueOf(employeeNext.getEmployeeNumber()));
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return employeeNums;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
