package project2gui;

/**
 *
 * @author Matt
 */
public class Employee {
    private int employeeNumber;
    private String employeeName;
    private int territoryNumber;
    private int annualSalary;

    /**
     * @return the employeeNumber
     */
    public int getEmployeeNumber() {
        return employeeNumber;
    }

    /**
     * @param employeeNumber the employeeNumber to set
     */
    public void setEmployeeNumber(int employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    /**
     * @return the employeeName
     */
    public String getEmployeeName() {
        return employeeName;
    }

    /**
     * @param employeeName the employeeName to set
     */
    public void setEmployeeName(String employeeName) {
        this.employeeName = employeeName;
    }

    /**
     * @return the territoryNumber
     */
    public int getTerritoryNumber() {
        return territoryNumber;
    }

    /**
     * @param territoryNumber the territoryNumber to set
     */
    public void setTerritoryNumber(int territoryNumber) {
        this.territoryNumber = territoryNumber;
    }

    /**
     * @return the annualSalary
     */
    public int getAnnualSalary() {
        return annualSalary;
    }

    /**
     * @param annualSalary the annualSalary to set
     */
    public void setAnnualSalary(int annualSalary) {
        this.annualSalary = annualSalary;
    }
    
}
