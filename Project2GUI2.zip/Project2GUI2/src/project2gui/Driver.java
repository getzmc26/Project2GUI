package project2gui;

import javafx.application.Application;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

/**
 * Driver for Database Operations GUI.
 * @author Matt
 */
public class Driver extends Application {

    @Override
    public void start(Stage stage) {
        DatabaseOperationsGUI dbg = new DatabaseOperationsGUI();
        BorderPane borderPane = dbg.selectDatabasePane();
        dbg.getStage().setTitle("Derby Database GUI");
        dbg.getStage().setScene(dbg.getScene());
        dbg.getStage().show();
    }

    public static void main(String[] args) {
        launch(args);
    }

}
